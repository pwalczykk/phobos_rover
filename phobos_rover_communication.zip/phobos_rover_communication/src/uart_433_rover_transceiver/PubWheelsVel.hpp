#ifndef PubWheelsVel_HPP_
#define PubWheelsVel_HPP_

#include <ros/ros.h>
#include <phobos_shared/WheelsVel16.h>

class PubWheelsVel{
    ros::NodeHandle *nh;
    ros::Publisher pub;
public:
    phobos_shared::WheelsVel16 msg;
public:
    PubWheelsVel(std::string topic, ros::NodeHandle *nh){
        this->nh = nh;
        this->pub = nh->advertise<phobos_shared::WheelsVel16>(topic, 100);
    }
    ~PubWheelsVel(){}

    void Publish(){
        this->pub.publish(msg);
    }

    void Publish(int wheels_left, int wheels_right){
        this->msg.wheels_left = wheels_left;
        this->msg.wheels_right = wheels_right;
        this->pub.publish(msg);
    }
};

#endif
